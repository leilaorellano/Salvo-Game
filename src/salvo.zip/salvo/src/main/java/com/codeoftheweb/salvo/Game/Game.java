package com.codeoftheweb.salvo.Game;

import com.codeoftheweb.salvo.GamePlayer.GamePlayer;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

@Entity
public class Game {

    @Id //es un numero que se le asigna a cada "gameplayer"
    @GeneratedValue (strategy = GenerationType.AUTO, generator = "native")
    @GenericGenerator(name = "native", strategy = "native")
    private long id;

//Es OneToMany porque un juego puede tener muchos GamePlayers

    @OneToMany(mappedBy="game", fetch=FetchType.EAGER)
    private Set<GamePlayer> players; //Variable declarada de GamePlayer en Game


    private LocalDateTime joinDate;

    // Constructor //
    public Game() {
    }

    public Game(LocalDateTime joinDate) {
        this.joinDate = joinDate;
    }


//Getter y Setter
    public Long getId() {
        return id;
    }

    public LocalDateTime getJoinDate() {
        return joinDate;
    }

    public Set<GamePlayer> getGamePlayers() {
        return players;
    }


    // Esto es para el OneToMany
    public void addGamePlayer(GamePlayer gamePlayer) {
        gamePlayer.setGame(this);
        players.add(gamePlayer);
    }
//DTOs
    public Map<String, Object> gameDTO(){
        Map<String, Object> dto= new HashMap<>();
        dto.put("id", id);
        dto.put("joinDate", joinDate);
        dto.put("players", players.stream().map(GamePlayer::gamePlayerDTO).collect(Collectors.toList()));

        return dto;
    }

}


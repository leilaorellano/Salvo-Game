package com.codeoftheweb.salvo;

import com.codeoftheweb.salvo.Game.GameRepository;
import com.codeoftheweb.salvo.GamePlayer.GamePlayer;
import com.codeoftheweb.salvo.GamePlayer.GamePlayerRepository;
import com.codeoftheweb.salvo.Player.PlayerRepository;
import com.codeoftheweb.salvo.Ship.ShipRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
//Los controladores REST definen métodos que obtienen datos de una solicitud, modifican opcionalmente datos en una base de datos
// y finalmente devuelven un objeto que se puede convertir a JSON para enviar de vuelta al cliente web.

@RestController
@RequestMapping("/api")
public class SalvoController {

    @Autowired
    private GameRepository gameRepository;

    @Autowired
    private PlayerRepository playerRepository;

    @Autowired
    private GamePlayerRepository gamePlayerRepository;

    @Autowired
    private ShipRepository shipRepository;

    @Autowired
    private SalvoRepository salvoRepository;

    //Necesito encontrar findAll() métodos para retornar una lista/set
    @RequestMapping("/games")
    public List<Object> getGamesId() {
        return gameRepository.findAll().stream().map(game -> game.gameDTO()).collect(Collectors.toList());
    }

    @RequestMapping("/players")
    public List<Object> getPlayersId() {
        return playerRepository.findAll().stream().map(player -> player.playerDTO()).collect(Collectors.toList());
    }

   @RequestMapping("/game_view/{gamePlayerId}") // @PathVariable obtiene el valor especifico de una url ?
    public ResponseEntity <Map <String,Object>> gamePlayers(@PathVariable long gamePlayerId){
        Optional<GamePlayer> gp= gamePlayerRepository.findById(gamePlayerId);

       ResponseEntity<Map<String, Object>> response ;
       if (!gp.isEmpty()){
           response= new ResponseEntity<>(gp.get().game_view(),HttpStatus.OK);
       }else{
           response=  new ResponseEntity<>(makeMap("problem","gameplayer doesn't exist"), HttpStatus.NOT_ACCEPTABLE);
       }
       return response;
   }

   private  Map<String , Object> makeMap(String key, Object value) {
        Map<String , Object> map = new HashMap<>();
        map.put(key,value);
        return map;
   }

}
package com.codeoftheweb.salvo.GamePlayer;

import com.codeoftheweb.salvo.Game.Game;
import com.codeoftheweb.salvo.Player.Player;
import com.codeoftheweb.salvo.Salvo;
import com.codeoftheweb.salvo.Ship.Ship;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

@Entity
public class GamePlayer {

    @Id //es un numero que se le asigna a cada "game"
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "native")
    @GenericGenerator(name = "native", strategy = "native")
    private Long id;

    private LocalDateTime joinDate;

// Es ManyToOne porque hay muchos gameplayers para cada player o game
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name="player_id")// player id es el nombre de la columna
    private Player player; //creo la case con la que la voy a relacionar

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name="game_id")// game id es el nombre de la columna
    private Game game;

    @OneToMany(mappedBy = "gamePlayers", fetch = FetchType.EAGER)
    private Set<Salvo> salvo = new HashSet<>();

    @OneToMany(mappedBy = "gamePlayers", fetch = FetchType.EAGER)
    private Set<Ship> ship = new HashSet<>();

                            //CONSTRUCTOR
    public GamePlayer() { //Contructor vacio.
    }

    public GamePlayer(Player player, Game game ) {
        this.joinDate= LocalDateTime.now();
        this.player = player;
        this.game = game;
    }
                           //GETTER Y SETTER
    public Long getId() { return id; }

    public LocalDateTime getJoinDate() { return joinDate; }

    public void setJoinDate(LocalDateTime joinDate) { this.joinDate = joinDate; }

    public Player getPlayer() { return player; }

    public void setPlayer(Player player) { this.player = player; }

    public Game getGame() { return game; }

    public void setGame(Game game) { this.game = game; }

    public Set<Ship> getShip() { return ship; }

    public void setShip(Set<Ship> ship) { this.ship = ship; }

    public Set<Salvo> getSalvo() { return salvo; }

    public void setSalvo(Set<Salvo> salvo) { this.salvo = salvo; }

    //DTO
    public Map<String , Object> gamePlayerDTO(){
        Map<String, Object> dto = new LinkedHashMap<>();
        dto.put("id", id);
        dto.put("player", player.playerDTO());

        return dto;
    }

    public Map<String,Object> game_view(){
     Map<String,Object> dto = new LinkedHashMap<>();
     dto.put("created" , game.getJoinDate());
     dto.put("id", game.getId());
     dto.put("gamePlayers", game.getGamePlayers().stream().map(GamePlayer::gamePlayerDTO).collect(Collectors.toSet()));
     dto.put("ships",ship.stream().map(Ship::shipDTO).collect(Collectors.toSet()));
     dto.put("salvoes", game.getGamePlayers().stream().flatMap(a -> a.getSalvo().stream().map(b ->b.salvoDTO())).collect(Collectors.toList()));
   //a y b son nombres de la funcion
     return dto;
    }

}
package com.codeoftheweb.salvo;

import com.codeoftheweb.salvo.Game.Game;
import com.codeoftheweb.salvo.Game.GameRepository;
import com.codeoftheweb.salvo.GamePlayer.GamePlayer;
import com.codeoftheweb.salvo.GamePlayer.GamePlayerRepository;
import com.codeoftheweb.salvo.Player.Player;
import com.codeoftheweb.salvo.Player.PlayerRepository;
import com.codeoftheweb.salvo.Ship.Ship;
import com.codeoftheweb.salvo.Ship.ShipRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;

@SpringBootApplication
public class SalvoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SalvoApplication.class, args);
	}

	@Bean
	public CommandLineRunner initData(PlayerRepository playerRepository , GameRepository gameRepository, GamePlayerRepository gamePlayerRepository ,
									  ShipRepository shipRepository , SalvoRepository salvoRepository) {
		return (args) -> {
			//No olvidar poner todos los repositorios en el CommandLineRunner!!!!!!
            //Players
			Player player1 = playerRepository.save(new Player("Jack"));
			Player player2 = playerRepository.save(new Player("Chloe"));
			Player player3 = playerRepository.save(new Player("Kim"));
			Player player4 = playerRepository.save(new Player("Messi"));
			Player player5 = playerRepository.save(new Player("Leila"));

            //Games
			Game game1 = gameRepository.save(new Game(LocalDateTime.now()));
			Game game2 = gameRepository.save(new Game(LocalDateTime.now().plusHours(1)));
			Game game3 = gameRepository.save(new Game(LocalDateTime.now().plusHours(2)));
			Game game4 = gameRepository.save(new Game(LocalDateTime.now().plusHours(3)));
			Game game5 = gameRepository.save(new Game(LocalDateTime.now().plusHours(4)));


			//GamePlayers
			GamePlayer gp1 = gamePlayerRepository.save(new GamePlayer(player1,game1));
			GamePlayer gp2 = gamePlayerRepository.save(new GamePlayer(player2,game1));

            GamePlayer gp3 = gamePlayerRepository.save(new GamePlayer(player3,game2));
            GamePlayer gp4 = gamePlayerRepository.save(new GamePlayer(player4,game2));


            //Ships
			ArrayList<String> shipPosition1 = new ArrayList<>(Arrays.asList("B5","B6","B7","B8","B9"));
			ArrayList<String> shipPosition2 = new ArrayList<>(Arrays.asList("C5","C6","C7"));
			ArrayList<String> shipPosition3 = new ArrayList<>(Arrays.asList("F3","G3","H3"));
			ArrayList<String> shipPosition4 = new ArrayList<>(Arrays.asList("G4","G5","G6","G7"));
			ArrayList<String> shipPosition5 = new ArrayList<>(Arrays.asList("E1","F1","G1"));
			ArrayList<String> shipPosition6 = new ArrayList<>(Arrays.asList("B4","B5"));
			ArrayList<String> shipPosition7 = new ArrayList<>(Arrays.asList("B8","B9"));
			ArrayList<String> shipPosition8 = new ArrayList<>(Arrays.asList("G4","G5","G6","G7","G8"));


			//Salvoes
			ArrayList<String> salvoPosition1 = new ArrayList<>(Arrays.asList("B5","C5","F1"));
			ArrayList<String> salvoPosition2 = new ArrayList<>(Arrays.asList("B4","B5","B6"));
			ArrayList<String> salvoPosition3 = new ArrayList<>(Arrays.asList("F2","D5"));
			ArrayList<String> salvoPosition4 = new ArrayList<>(Arrays.asList("E1","H3","A2"));
			ArrayList<String> salvoPosition5 = new ArrayList<>(Arrays.asList("A2","A4","G6"));
			ArrayList<String> salvoPosition6 = new ArrayList<>(Arrays.asList("B5","D5","C7"));
			ArrayList<String> salvoPosition7 = new ArrayList<>(Arrays.asList("A3","H6"));
			ArrayList<String> salvoPosition8 = new ArrayList<>(Arrays.asList("C5","C6"));


            Ship ship1 = new Ship("Carrier",gp1,shipPosition1);
            Ship ship2 = new Ship("Submarine",gp1,shipPosition2);
            Ship ship3 = new Ship("Destroyer",gp2,shipPosition3);
            Ship ship4 = new Ship("Battleship",gp2,shipPosition4);
            Ship ship5 = new Ship("Destroyer",gp3,shipPosition5);
            Ship ship6 = new Ship("Patrol Boat",gp3,shipPosition6);
			Ship ship7 = new Ship("Patrol Boat",gp4,shipPosition7);
            Ship ship8 = new Ship("Carrier",gp4,shipPosition8);

			Salvo salvo1 = new Salvo(1,gp1,salvoPosition1);
			Salvo salvo2 = new Salvo(2,gp1,salvoPosition2);
			Salvo salvo3 = new Salvo(3,gp2,salvoPosition3);
			Salvo salvo4 = new Salvo(4,gp2,salvoPosition4);
			Salvo salvo5 = new Salvo(5,gp3,salvoPosition5);
			Salvo salvo6 = new Salvo(6,gp3,salvoPosition6);
			Salvo salvo7 = new Salvo(7,gp4,salvoPosition7);
			Salvo salvo8 = new Salvo(8,gp4,salvoPosition8);

            shipRepository.save(ship1);
            shipRepository.save(ship2);
            shipRepository.save(ship3);
            shipRepository.save(ship4);
            shipRepository.save(ship5);
            shipRepository.save(ship6);
            shipRepository.save(ship7);
            shipRepository.save(ship8);

            salvoRepository.save(salvo1);
			salvoRepository.save(salvo2);
			salvoRepository.save(salvo3);
			salvoRepository.save(salvo4);
			salvoRepository.save(salvo5);
			salvoRepository.save(salvo6);
			salvoRepository.save(salvo7);
			salvoRepository.save(salvo8);

		};
	}
}
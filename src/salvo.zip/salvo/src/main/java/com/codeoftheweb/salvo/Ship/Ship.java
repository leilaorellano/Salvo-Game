package com.codeoftheweb.salvo.Ship;

import com.codeoftheweb.salvo.GamePlayer.GamePlayer;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Entity
public class Ship {

    @Id //es un numero que se le asigna a cada "player"
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "native")
    @GenericGenerator(name = "native", strategy = "native")
    private long id;

    private String type;

   @ManyToOne(fetch=FetchType.EAGER)
   @JoinColumn(name = "gamePlayer_id")
   private GamePlayer gamePlayers;

   @ElementCollection
   @Column(name = "positions")
   private List<String> shipPositions;

    //Constructor
    public Ship() {

    }

    public Ship (String type, GamePlayer gamePlayers, ArrayList<String> shipPositions) {
        this();
        this.type = type;
        this.gamePlayers= gamePlayers;
        this.shipPositions= shipPositions;
    }

    public GamePlayer getGamePlayers() { return gamePlayers; }

    public void setGamePlayers(GamePlayer gamePlayers) {
        this.gamePlayers = gamePlayers;
    }

    public long getId() { return id; }

    public String getType() { return type; }

    public void setType(String type) { this.type = type; }

    public List<String> getShipPositions() { return shipPositions; }

    public void setShipPositions(ArrayList<String> shipPositions) { this.shipPositions = shipPositions; }

//DTO
    public Map<String, Object> shipDTO(){
        Map<String, Object> dto= new HashMap<>();
        dto.put("id", id);
        dto.put("type", type);
        dto.put("locations", shipPositions);

        return dto;
    }

}


